﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum ApplicationType
    {
        None = 0,
        Portal = 1,
        Integracion = 2,
        AppMovil = 3
    }
}
