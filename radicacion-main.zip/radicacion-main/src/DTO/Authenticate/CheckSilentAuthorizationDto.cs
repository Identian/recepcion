﻿namespace DTO.Authenticate
{
    public class CheckSilentAuthorizationDto
    {
        public string? State { get; set; }
    }
}
