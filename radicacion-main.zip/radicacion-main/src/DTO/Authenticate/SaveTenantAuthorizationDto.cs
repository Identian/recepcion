﻿namespace DTO.Authenticate
{
    public class SaveTenantAuthorizationDto
    {
        public string? State { get; set; }
        public string? TenantId { get; set; }
    }
}
