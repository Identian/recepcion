﻿namespace DTO.GestionCorreoDto
{
    public class InfoReceptorDto
    {
        public CuentaCorreoDto cb { get; set; }
        public ReceptorDto r { get; set; }
    }
}
