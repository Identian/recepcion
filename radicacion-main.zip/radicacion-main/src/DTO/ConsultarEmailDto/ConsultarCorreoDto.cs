﻿namespace DTO.ConsultarEmailDto
{
    public class ConsultarCorreoDto
    {
        public string? NIT { get; set; }
        public string? TipoIdentificacion { get; set; }
    }
}
