﻿namespace DTO.ConsultarEmailDto
{
    public class ConsultarCorreoParamsDto
    {
        public string? numeroIdentificacion { get; set; }
        public string? tipoIdentificacion { get; set; }
    }
}
