﻿using CapaDominio.Interfaces.IHelpers;

namespace Infraestructura.Helpers
{
    public class Utils : IUtils
    {

    }
}

