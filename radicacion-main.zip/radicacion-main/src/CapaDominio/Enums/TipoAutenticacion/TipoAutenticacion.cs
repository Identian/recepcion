﻿namespace CapaDominio.Enums.TipoAutenticacion
{
    public enum TipoAutenticacion
    {
        AUTENTICACION_BASICA,
        MICROSOFT_OAUTH_CODIGO,
        MICROSOFT_OAUTH_APLICACION
    }
}
