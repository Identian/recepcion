﻿namespace CapaDominio.Enums.Logs
{
    public enum LevelMsn
    {
        Info = 1,
        Warning,
        Error
    }
}
