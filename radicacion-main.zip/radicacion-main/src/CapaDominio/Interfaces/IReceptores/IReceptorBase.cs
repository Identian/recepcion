﻿namespace CapaDominio.Interfaces.IReceptores
{
    public interface IReceptorBase : IReceptorBaseParams
    {
        void Clear();
    }
}