﻿namespace CapaDominio.Auth
{
    public class CheckSilentAuthorization
    {
        public string? State { get; set; }
    }
}
