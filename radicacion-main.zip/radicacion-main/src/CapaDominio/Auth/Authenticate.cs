﻿namespace CapaDominio.Auth
{
    public class Authenticate
    {
        public string? State { get; set; }
        public string? TenantId { get; set; }
    }
}
