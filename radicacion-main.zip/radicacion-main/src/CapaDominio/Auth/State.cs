﻿namespace CapaDominio.Auth
{
    public class State
    {
        public int Id_receptor { get; set; }

        public string? Email { get; set; }
    }
}
