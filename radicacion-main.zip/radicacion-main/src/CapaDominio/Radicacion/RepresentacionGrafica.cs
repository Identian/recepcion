﻿namespace CapaDominio.Radicacion
{
    public class RepresentacionGrafica
    {
        public string? nitEmisor { get; set; }
        public string? numeroDocumento { get; set; }
        public string? nombre { get; set; }
        public string? TipoIdentificacionEmisor { get; set; }
        public string? TipoDocumento { get; set; }
    }
}
