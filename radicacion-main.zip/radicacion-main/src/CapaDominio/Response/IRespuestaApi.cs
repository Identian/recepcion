﻿namespace CapaDominio.Response
{
    public interface IRespuestaApi
    {
        int Codigo { get; set; }
        string Mensaje { get; set; }
    }
}