﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDominio.Entity
{
    public class JsonLogs
    {
        public List<string> Log { get; set; } = new List<string>();
    }
}
