﻿namespace CapaDominio.Receptor
{
    public class ConsultaEmail
    {
        public string? NumeroIdentificacion { get; set; }
        public string? TipoIdentificacion { get; set; }
    }
}
