﻿namespace Receptores.Logs
{
    public enum LevelMsn
    {
        Info = 1,
        Warning,
        Error
    }

}
