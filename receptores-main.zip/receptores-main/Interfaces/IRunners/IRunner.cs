﻿namespace Receptores.Interfaces.IRunners
{
    public interface IRunner
    {
        Task<long> ExcuteRunner();
    }
}