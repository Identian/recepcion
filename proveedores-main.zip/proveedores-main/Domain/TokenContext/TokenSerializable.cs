﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.TokenContext
{
    public class TokenSerializable
    {
        public CustomJwtTokenContext? User { get; set; }
    }
}
