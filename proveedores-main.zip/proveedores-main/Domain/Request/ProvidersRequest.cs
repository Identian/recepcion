﻿

namespace Domain.Request
{
    public  class ProvidersRequest
    {
        public int IdProvider { get; set; }
        public bool Estatus { get; set; }
    }
}
