﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfRecepcionSOAP.Models.Responses
{
	public class InvitacionResponse
	{
		public int codigo { get; set; }

		public String mensaje { get; set; }
	}
}